[System.Serializable]
public class QnA
{
    public string questions;
    public string[] answers;
    public int correctAnswer;
}
