using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class TutorialText
{
    [TextArea(3, 10)]
    public string[] TutorialSentences;
}
